// Budgets votés et comptes administratifs.
// Lu dans le snapshot au build — cf. marches/+page.server.js pour le motif.
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

export const prerender = true

const lire = (nom, defaut = {}) => {
  try { return JSON.parse(readFileSync(join(process.cwd(), 'static', 'data', nom), 'utf8')) }
  catch { return defaut }  // snapshot absent : page vide plutôt que build cassé
}

export function load() {
  return {
    budgetVote: lire('budget_vote.json', {}),
    budget: lire('budget.json', {}),
    ofgl: lire('ofgl.json', { ofgl: [] }),
  }
}
